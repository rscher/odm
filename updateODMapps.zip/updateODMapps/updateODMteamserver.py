AdminApplication.deleteSingleFileToAnAppWithUpdateCommand("teamserver", "/log4j-1.2.8.jar", "teamserver.war/WEB-INF/lib/log4j-1.2.8.jar")
AdminApplication.addSingleFileToAnAppWithUpdateCommand("teamserver", "./log4j-1.2.8-ibmpatch-2.jar", "teamserver.war/WEB-INF/lib/log4j-1.2.8-ibmpatch-2.jar")

AdminConfig.save()
