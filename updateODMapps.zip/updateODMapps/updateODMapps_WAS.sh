#!/bin/bash
#
# updateODMapps_WAS.sh  <Dmgr_home_location> <wasUserName> <wasPassword> 
#
#  Update ODM enterprise apps in WAS855 with log4j-1.2.8-ibmpatch-2.jar
# --------------------------------

DMGR_HOME=$1
user=$2
password=$3
tmpLog=/tmp/.ODM_apps 

if [[ $# != 3 ]] ; then
    echo "usage: updateODMapps_WAS.sh <Dmgr_home_location> <wasUserName> <wasPassword>"
    exit -1
fi

if [[ !  -f "$1/bin/startManager.sh" ]] ; then
   echo "$1 is not <Dmgr_home_location>" 
   echo "usage: updateODMapps_WAS.sh <Dmgr_home_location> <wasUserName> <wasPassword>"
   exit -1
fi

$DMGR_HOME/../../bin/managesdk.sh -setCommandDefault    -sdkname 1.8_64_bundled
$DMGR_HOME/../../bin/managesdk.sh -setNewProfileDefault -sdkname 1.8_64_bundled 

$DMGR_HOME/bin/wsadmin.sh -lang jython -user $2 -password $3 -f getODMapps.py &> $tmpLog >&1 

resInstalled=$(grep jrules-res-management $tmpLog) 
teamserverInstalled=$(grep teamserver $tmpLog) 

if [[ resInstalled ]] ; then
 $DMGR_HOME/bin/wsadmin.sh -lang jython -user $2 -password $3 -f updateODMres.py 
fi

if [[ teamserverInstalled ]] ; then
 $DMGR_HOME/bin/wsadmin.sh -lang jython -user $2 -password $3 -f updateODMteamserver.py
fi

rm -f $tmpLog
