import sys

applist = AdminApp.list().split("\n")
for a in applist:
    print a
    continue
