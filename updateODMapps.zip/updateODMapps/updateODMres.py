AdminApplication.deleteSingleFileToAnAppWithUpdateCommand("jrules-res-management", "/log4j-1.2.8.jar", "jrules-res-management.war/WEB-INF/lib/log4j-1.2.8.jar")
AdminApplication.addSingleFileToAnAppWithUpdateCommand("jrules-res-management", "./log4j-1.2.8-ibmpatch-2.jar", "jrules-res-management.war/WEB-INF/lib/log4j-1.2.8-ibmpatch-2.jar")

AdminApplication.deleteSingleFileToAnAppWithUpdateCommand("jrules-ssp", "/log4j-1.2.8.jar", "jrules-ssp-server.war/WEB-INF/lib/log4j-1.2.8.jar")
AdminApplication.addSingleFileToAnAppWithUpdateCommand("jrules-ssp", "./log4j-1.2.8-ibmpatch-2.jar", "jrules-ssp-server.war/WEB-INF/lib/log4j-1.2.8-ibmpatch-2.jar")

AdminConfig.save()
