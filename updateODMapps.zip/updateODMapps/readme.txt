'''
   Sample script (Unlicensed Materials - provided by IBM)
   for example purposes only. 
   Customer to run at thier own risk as 
   Entitlement support not provided, IBM is not liable or 
   responsible for results within customer environments.
   Copyright IBM Corp. 1987, 2018, 2022. All Rights Reserved.

'''

********************* 

Usage instructions: script updates installed ODM 892 ear files within WAS 855 cluster 
 replacing log4j-1.2.8.jar with patched version, log4j-1.2.8-ibmpatch-2.jar.
 log4j-1.2.8-ibmpatch-2.jar contained in zip file and must be in the same folder
  as the script files.

 # before running script:
 # log4j-1.x.jar found in 3 ODM enterprise apps

./jrules-res-management.ear/jrules-res-management.war/WEB-INF/lib/log4j-1.2.8.jar
./jrules-ssp.ear/jrules-ssp-server.war/WEB-INF/lib/log4j-1.2.8.jar
./teamserver.ear/teamserver.war/WEB-INF/lib/log4j-1.2.8.jar
 
-Unzip updateODMapps_WAS.zip into a new folder.
-Ensure updateODMapps_WAS.sh is runnable within Linux bash shell:
   chmod +x updateODMapps_WAS.sh 

 script usage:
   updateODMapps_WAS.sh <Dmgr_home_location> <wasUserName> <wasPassword>

  takes 3 arguments: Dmgr_home_location , was admin username, was admin password
  checks if Dmgr_home_location is correct, exits if incorrect location entered
  exits if was admin username and password not specified
  script will fail with error message if supplied was credentials are incorrect.

------------------------- 

 Results after script completes:
 
 from:  ../<ODM Node>/installedApps/<odmCell>

 $  find . -name log4j*.jar
 ./jrules-res-management.ear/jrules-res-management.war/WEB-INF/lib/log4j-1.2.8-ibmpatch-2.jar
 ./jrules-ssp.ear/jrules-ssp-server.war/WEB-INF/lib/log4j-1.2.8-ibmpatch-2.jar
 ./teamserver.ear/teamserver.war/WEB-INF/lib/log4j-1.2.8-ibmpatch-2.jar
